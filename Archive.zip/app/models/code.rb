class Code < ActiveRecord::Base
  belongs_to :device
end
