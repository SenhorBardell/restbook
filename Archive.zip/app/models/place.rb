class Place < ActiveRecord::Base
end
