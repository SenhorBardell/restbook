class User < ActiveRecord::Base
  has_many :devices
end
